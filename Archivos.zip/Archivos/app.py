import os, json, requests
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

AML_ENDPOINT_URL = os.environ.get("AML_ENDPOINT_URL")
AML_API_KEY = os.environ.get("AML_API_KEY")

COLUMNS = ["Pregunta_1","Pregunta 2","Pregunta 3","Pregunta 6","Pregunta 7","Sum_Insuf"]

@app.get("/health")
def health():
    ok = bool(AML_ENDPOINT_URL and AML_API_KEY)
    return jsonify({"status": "ok" if ok else "misconfigured"}), 200 if ok else 500

@app.post("/predict")
def predict():
    data = request.get_json(force=True) or {}
    p1, p2, p3, p6, p7 = data.get("Pregunta_1"), data.get("Pregunta_2"), data.get("Pregunta_3"), data.get("Pregunta_6"), data.get("Pregunta_7")

    if None in [p1,p2,p3,p6,p7]:
        return jsonify({"error":"Faltan preguntas"}), 400

    sum_insuf = data.get("Sum_Insuf", float(p1)+float(p2)+float(p3)+float(p6)+float(p7))

    aml_payload = {
        "input_data": {
            "columns": COLUMNS,
            "index": [0],
            "data": [[float(p1), float(p2), float(p3), float(p6), float(p7), float(sum_insuf)]]
        }
    }
    headers = {"Content-Type":"application/json","Authorization":f"Bearer {AML_API_KEY}"}
    resp = requests.post(AML_ENDPOINT_URL, data=json.dumps(aml_payload), headers=headers, timeout=30)
    try:
        out = resp.json()
    except:
        out = {"raw": resp.text}
    return jsonify(out)

@app.get("/")
def home():
    return "Tu API Flask está funcionando. Usa /predict para hacer predicciones."
